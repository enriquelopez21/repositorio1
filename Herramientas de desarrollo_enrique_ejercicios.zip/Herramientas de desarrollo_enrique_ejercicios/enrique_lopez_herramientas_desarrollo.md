**1.¿Para que sirve un compilador? ¿Qué tipo de archivo obtenemos tras compilar? **
 Sirve para traducir un un programa que ha sido escrito en un lenguaje de programacióna un lenguaje común. 
 Un archivo que puede ser interpretado por la máquina.
** 2. ¿Para que sirve un enlazador? ¿Qué tipo de archivo obtenemos tras enlazar?**
Sirve para tomar los objetos generados en los primeros pasos del proceso de compilación, la información de todos los recursos necesarios (biblioteca), quita aquellos recursos que no necesita, y enlaza el código objeto con su(s) biblioteca(s) con lo que finalmente produce un fichero ejecutable o una biblioteca.
**3.¿Para que sirve un interprete? ¿Obtenemos algún archivo tras interpretar?**
Ejecuta el programa directamente, traduciendo cada sentencia en una secuencia de una o más subrutinas ya compiladas en código máquina.
Normalmente no guardan el resultado de dicha traducción.
**4.Explica cada uno de los siguientes conceptos e indica la relación entre ellos.**
-**Código fuente**: 
Es un conjunto de líneas de texto con los pasos que debe seguir la computadora para ejecutar dicho programa.
-**Código objeto**:
Código generado por un compilador o un ensamblador, traducido a partir del código fuente de un programa.
**-Código binario**
Es un sistema de representación de textos o de procesadores de instrucciones de una computadora, que hace uso del sistema binario.
**5.¿Qué tipo de código es el bytecode generado por el compilador de Java?**
Es un código intermedio más abstracto que el código máquina. Habitualmente es tratado como un archivo binario que contiene un programa ejecutable similar a un módulo objeto, que es un archivo binario producido por el compilador cuyo contenido es el código objeto o código máquina .
**2.Para cada uno de los lenguajes anteriores, indica el proceso realizado para conseguir ejecutar el código: ¿compilación o interpretación?**
**Interpretado** (bash)
*#!/bin/bash* 
  echo "Hola mundo"

**Interpretado** (python)
*#!/usr/bin/env python*
print "Hola Mundo"

**Interpretado** (php)
*#!/usr/bin/env php*
<?php
echo "Hola mundo\n"
?>

**Interpretado** (JavaScript)
//Caso write()
document.write("Hola Mundo!");
//Caso alert()
alert("Hola Mundo!");
//Caso console.log()
console.log("Hola Mundo!");
Compilado (gcc)
*#include <stdio.h>*

int main()
{
    printf("¡Hola, mundo!");
    return 0;
}

**Interpretado** (c)
*#include <stdio.h>*

int main(void)
{
    printf("¡Hola, mundo!");
}

**Compilado** (c++)
*#include <iostream>* 

using namespace std;

int main()
{
   cout << "¡Hola, mundo!" << endl;
   return 0;
}

**Interpretado** (java)
class HolaMundo
{
    public static void main(String[] args)
    {
        System.out.println("Hola Mundo");//Opcion 1

        JOptionPane.showMessageDialog(null,"Hola Mundo");//Opcion 2
    }
}

**Interpretado** (Ruby)
 puts "Hola Mundo"
 
 **Compilado** (go)
 package main

import "fmt"

func main() {
	fmt.Println("Hola mundo desde Go")
}

**Compilado** (rust)
fn main() {
    println("¡Hola, mundo!");
}

**Interpretado** (lisp)
 (format t "¡Hola, mundo!")

 "¡Hola, mundo!"

**Bajo Nivel** (lenguaje ensamblador)
section .data
 
 msg     db "¡Hola Mundo!", 0Ah
 len     equ     $ - msg  
 
 section .text
 
 global _start
 
 _start:
        mov     eax, 04h
        mov     ebx, 01h
        mov     ecx, msg
        mov     edx, len
        int     80h
        mov     eax, 01h
        mov     ebx, 00h
        int     80h

3.Para cada uno de los lenguajes anteriores, indica el nombre del compilador o interprete utilizado en GNU/Linux.
4. Investiga y averigua que extensión tienen los archivos de código fuente de los siguientes lenguajes:
bash: .sh
python: .py
php: .php
javascript: .js
c: .c
c++: .cpp
java: .java
ensamblador: .asm
ruby: .rb
go: .go
rust: .rs
lisp: .lisp
5. Scripts ejecutables para los lenguajes interpretados. Edita los scripts para los siguientes lenguajes:
**bash**

*#!/usr/bin/env bash*

echo "Hola mundo"

**python**
*#!/usr/bin/env python*

print "Hola Mundo"
php
*#!/usr/bin/env php*

<?php
echo "Hola mundo\n"
?>
javascript
*#!/usr/bin/env node*

console.log('Hola mundo');
**java**
class Hola
{
    public static void main(String[] args)
    {
        System.out.println("Hola Mundo");
    }
}
**ruby**
*#!/usr/bin/env ruby*

puts "Hola Mundo"
**go**
package main

import "fmt"

func main() {
	fmt.Println("Hola mundo desde Go")
}
**rust**
fn main() {
    println!("¡Hola, mundo! Desde RUST ");
}
**lisp**
*#!/usr/bin/env clisp*

(format t "¡Hola, mundo!")
**6. ¿Qué extensión tienen los archivos de código objeto?**
.OBJ
**11.Bibliotecas. Define que se entiende por biblioteca o librería y los tipos que existen.**
Es un conjunto de implementaciones funcionales, codificadas en un lenguaje de programación, que ofrece una interfaz bien definida para la funcionalidad que se invoca.
**Bibliotecas Estáticas**
Es una librería que "se copia" en nuestro programa cuando lo compilamos. Una vez que tenemos el ejecutable de nuestro programa, la librería no sirve para nada (es un decir, sirve para otros futuros proyectos). Podríamos borrarla y nuestro programa seguiría funcionando, ya que tiene copia de todo lo que necesita. Sólo se copia aquella parte de la librería que se necesite. Por ejemplo, si la librería tiene dos funciones y nuestro programa sólo llama a una, sólo se copia esa función.
**Biblioteca Dinámica**
NO se copia en nuestro programa al compilarlo. Cuando tengamos nuestro ejecutable y lo estemos ejecutando, cada vez que el código necesite algo de la librería, irá a buscarlo a ésta. Si borramos la librería, nuestro programa dará un error de que no la encuentra.
**Bibliotecas Remotas**
Procedimiento remoto sobre la red a otra computadora conocido como remote procedure call o RPC.
**12.Bibliotecas. ¿Qué tipo es el más utilizado actualmente? ¿Por qué?**
Diria que el dinámico ya que con el se pueden crear grandes proyectos.
**15.Bibliotecas. Busca información y explica las ventajas y desventajas de usar bibliotecas estáticas.**
**Ventajas**
-Un programa compilado con librerías estáticas es más grande, ya que se hace copia de todo lo que necesita.
-Un programa compilado con librerías estáticas se puede llevar a otro ordenador sin necesidad de llevarse las librerías.

**Desventajas**
No se pueden hacer programas muy grandes.

16.Bibliotecas. Busca información y explica las ventajas y desventajas de usar bibliotecas dinámicas.
**Ventajas**
Se permite la reutilización no solo de código, sino de espacio físico: 
Puede reutilizarse memoria principal (RAM) para programas que utilicen la misma biblioteca.

**Desventajas**
El aumento del tiempo de carga (debido a tener que buscar el fichero de la biblioteca, cargarlo y relocalizar las llamadas en el programa) y el aumento de una indirección a la hora de llamar a las funciones de la biblioteca.

