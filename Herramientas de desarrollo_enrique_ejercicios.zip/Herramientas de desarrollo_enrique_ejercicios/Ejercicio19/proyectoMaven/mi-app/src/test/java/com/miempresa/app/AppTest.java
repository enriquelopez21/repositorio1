package com.miempresa.app;

import org.junit.Test;
import static org.junit.Assert.*;

public class AppTest {

  @Test
  public void testMain() {
      // Prueba vacía
  }

}
