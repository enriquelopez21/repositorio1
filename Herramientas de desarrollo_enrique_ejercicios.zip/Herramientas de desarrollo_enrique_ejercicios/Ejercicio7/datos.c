//-------------
// datos.c
//-------------

char *mensaje="Hola a todos y todas";
int num1 = 8;
int num2 =10;
