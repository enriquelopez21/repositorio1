int suma (int sumando1, int sumando2);

int resta  (int minuendo, int sustraendo);

int multiplicacion (int  numero1, int numero2);

float division (int dividendo, int divisor);
