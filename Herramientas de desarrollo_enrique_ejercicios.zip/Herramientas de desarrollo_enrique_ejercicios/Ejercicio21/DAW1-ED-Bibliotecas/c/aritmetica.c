int suma (int sumando1, int sumando2) {
	return (sumando1+sumando2);
}


int resta  (int minuendo, int sustraendo) {
	return (minuendo-sustraendo);
}


int multiplicacion (int  numero1, int numero2) {
	return (numero1*numero2);
}


float division (int dividendo, int divisor) {
	return (dividendo/(float)divisor);
}
