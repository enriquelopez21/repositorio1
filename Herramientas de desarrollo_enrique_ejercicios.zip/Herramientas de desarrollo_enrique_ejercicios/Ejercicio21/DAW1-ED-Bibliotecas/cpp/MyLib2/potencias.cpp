int cuadrado (int numero) {
	return (numero*numero);
}


int cubo     (int numero) {
	return (numero*numero*numero);
}

