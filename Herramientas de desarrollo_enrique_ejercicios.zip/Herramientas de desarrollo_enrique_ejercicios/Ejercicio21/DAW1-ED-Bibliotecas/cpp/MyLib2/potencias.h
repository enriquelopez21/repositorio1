int cuadrado (int numero);

int cubo     (int numero);

