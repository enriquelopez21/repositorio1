public class AritmeticaTest {
    
    @Test 
    public void testSuma() {
        assertEquals("Suma (2,3) = 5", 5, Aritmetica.suma(2,3));
    }

}
Edita el archivo build.gradle para que tenga el siguiente contenido:
apply plugin: 'java'
apply plugin: 'application'

repositories {
    jcenter()  
}

dependencies {
    testCompile 'junit:junit:4.12'         
}

jar {
    manifest {
       attributes ('Main-Class': 'Main')
    }
}

mainClassName = 'Main'
